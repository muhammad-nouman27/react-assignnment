import React from 'react'
 import dayjs from 'dayjs'

function Topbar() {
   
 
    return (
        <header className='bg-danger'>
            <div className="container">
                <div className="row">
                    <div className="col">
                        <p className="mb-0 text-center text-white">{
            dayjs().format("dddd, MMMM MM YYYY, hh:mm:ss a")
        }</p>
                    </div>
                </div>
            </div>
        </header>
    )
}

export default Topbar