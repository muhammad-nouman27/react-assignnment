
import Todo from './components/Noman/Todo';
import Index from "./components/Header/Index"
import Footer from "./components/Footer/Index"




function App() {
  
  return (
    <>
    <div >
    <Index/>
    <main>
    <Todo/>
    </main>
  
    <Footer/>
 
    </div>
    
      
    
    </>
  );
}

export default App;
